#create dictionary
student = {
    "name": "Raj",   
    "age": 20,
    "city": "Ahemadabad"
}
print("Original:", student)

# READ
print("Name:", student["name"])

# UPDATE / MODIFY
student["age"] = 21
print("After Update:", student)

# ADD 
student["marks"] = 85
print("After Adding:", student)

# DELETE 
del student["city"]
print("After Delete (using del):", student)


# keys()
print("Keys:", student.keys())

# values()
print("Values:", student.values())

# items()
print("Items:", student.items())

# get()
print("Get 'name':", student.get("name"))
print("Get 'grade':", student.get("grade", "Key not found!")) 

# update()
student.update({"city": "Delhi", "grade": "A"})
print("After update():", student)

# pop()
removed_value = student.pop("grade")
print(f"After pop('grade') - Removed value was '{removed_value}':", student)
