class Student:
    def __init__(self, rno, name):
        self.rno = rno
        self.name = name
    def getData(self):
        self.rno=int(input("Enter roll no "))
        self.name=(input("Enter Name "))
        self.age=int(input("Enter Age "))
        self.marks=[]
        for i in range(1,4):
            self.marks.append(int(input("Enter 3 Sub Marks")))
    def putData(self):
        print("Roll no : ",self.rno)
        print("Name : ",self.name)
        print("Age no : ",self.age)
        print("Marks : ",self.marks)
        print("Totol : ",self.total)
        print("Per : ",self.per)
    def calResult(self):
        self.total = sum(self.marks)
        self.per = self.total/3

s1 = Student(101, "Raj")
s1=Student()




s1.getData()
s1.calResult()
s1.putData()
