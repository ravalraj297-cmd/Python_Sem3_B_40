
class employee1:
    def __int__(self,empid=0,name="",Bsal=0):
        self.eid=empid
        self.name=name
        self.basic_sal=Bsal
        self.hra = 0
        self.da = 0
        self.pf = 0
        self.net_sal = 0

    def getData(self):
        self.eid=int(input("enter your employee id: "))
        self.name=(input("enter your name: "))
        self.basic_sal=int(input("enter your basic salary: "))

    def calculatesal(self):
        if self.basic_sal <= 5000:
             self.hra=self.basic_sal * 0.10
             self.da=self.basic_sal * 0.20
             self.pf=self.basic_sal * 0.05
        elif self.basic_sal <= 10000:
             self.hra=self.basic_sal * 0.20
             self.da=self.basic_sal * 0.40
             self.pf=self.basic_sal * 0.10
        elif self.basic_sal <= 20000:
            self.hra=self.basic_sal * 0.30
            self.da=self.basic_sal * 0.50
            self.pf=self.basic_sal * 0.07
        else:
            self.hra=self.basic_sal * 0.33
            self.da=self.basic_sal * 0.55
            self.pf=self.basic_sal * 0.09

        self.net_sal=self.basic_sal + self.hra + self.da
        self.total= self.net_sal - self.pf

    def putData(self):
            print("your employee id is", self.eid)
            print("your name is: ", self.name)
            print("your basic salary is: ",self.basic_sal)
            print("your hra is: ",self.hra)
            print("your da is: ",self.da)
            print("your pf is: ",self.pf)
            print("your net salary is: ",self.net_sal)
            print("your total salary is: ",self.total)  


    