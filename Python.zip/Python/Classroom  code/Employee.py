class Employee:
    def __init__(self, emp_id, name, salary):
        self.emp_id = emp_id
        self.name = name
        self.salary = salary
        
    def calculateSal(self):
        if self.salary <= 5000:
            hra = self.salary * 0.10
            da = self.salary * 0.20
            pf = self.salary * 0.05
        elif self.salary <= 10000:
            hra = self.salary * 0.15
            da = self.salary * 0.10
            pf = self.salary * 0.10
        else:
            hra = self.salary * 0.18
            da = self.salary * 0.07
            pf = self.salary * 0.09
            
        e_salary = self.salary + hra + da
        total_salary = e_salary - pf

        return hra, da, pf, e_salary, total_salary

    def displayData(self):
        hra, da, pf, e_salary, total_salary = self.calculateSal()

        print("\n--- Employee Details ---")
        print("Employee ID: ", self.emp_id)
        print("Employee Name: ", self.name)
        print("Salary: ", self.salary)
        print("HRA: ", hra)
        print("DA: ", da)
        print("PF: ", pf)
        print("Gross Salary: ", e_salary)
        print("Net Salary: ", total_salary)

        
employee = []

n = int(input("Enter Number of Employees: "))

emp_id = int(input("Enter Employee ID: "))
name = input("Enter Employee Name: ")
salary = float(input("Enter Employee Salary: ")) 
for i in range(n):
    print(f"\nEntering details for Employee {i+1}:")
    

    emp = Employee(emp_id, name,salary)
    employee.append(emp)

for emp in employee:
    emp.displayData()