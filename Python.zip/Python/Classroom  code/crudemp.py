import employee1

employees=[]

while True:
    print("\n=======employee menu========")
    print("1. Add Employee")
    print("2. Calculate Salary")
    print("3. Display All Employees")
    print("4. Search Employee by EID or Name")
    print("5. Delete Employee by EID or Name")
    print("6. Update Employee by EID or Name")
    print("7. Exit")

    ch=input("enter your choice: ")

    if ch == 1:
        emp = employee1.emp()
        emp.getData()
        found = False
        for e in employees:
            if e.eid == emp.eid:
                found = True
                break
        if found:
            print("Employee ID already exists!")
        else:
            emp.calculatesal()
            employees.append(emp)
            print("Employee added successfully.")

    elif ch == 2:
        if len(employees) == 0:
            print("No employee data available.")
        else:

            for emp in employees:
                emp.calSalary()

            print("Salary calculated successfully.")

    elif ch == 3:

        if len(employees) == 0:
            print("No employee data available.")
        else:

            for emp in employees:
                emp.putData()

    elif ch == 4:
        key = input("Enter employee EID or Name: ")
        found = False
        for emp in employees:
            if str(emp.eid) == key or emp.name.lower() == key.lower():
                emp.putData()
                found = True
        if not found:
            print("Employee not found.")

    elif ch == 6:
            if len(employees) == 0:
                print("No employee data available.")
            else:
                key = input("Enter employee EID or Name to update: ")
                found = False
                for i in range(len(emp)):
                    if (str(emp[i].eid)==key):
                        e1=employee1.emp()
                        e1.nm=input("Enter name")
                        e1.bs=int(input("Enter Salary"))
                        e1.eid=emp[i].eid
                        e1.calculatesal()
                        emp[i]=e1
                        found = True
                # for emp in employees:
                #     if str(emp.eid) == key or emp.name.lower() == key.lower():
                #         print("Enter new details:")
                #         emp.getData()
                #         emp.calculatesal()
                #         found = True
                #         print("Employee updated successfully.")
                #         break
                if not found:
                    print("Employee not found.")