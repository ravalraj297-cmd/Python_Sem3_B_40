class Emp:
    def __init__(self, emp_id=0, name=""):
        self.emp_id = emp_id
        self.name = name
        
    def getData(self):
        self.emp_id = int(input("Enter your employee ID: "))
        self.name = input("Enter your name: ")
        
    def putData(self):
        print("\n--- Employee Details ---")
        print("Employee ID: ", self.emp_id)
        print("Employee Name: ", self.name)


class Salary(Emp):
    def getData(self):
        super().getData()
        self.bs = float(input("Enter Employee Salary: ")) 

    def calculateSal(self):
        if self.bs <= 5000:
            self.hra = self.bs * 0.10
            self.da = self.bs * 0.20
            self.pf = self.bs * 0.05
        elif self.bs <= 10000:
            self.hra = self.bs * 0.15
            self.da = self.bs * 0.10
            self.pf = self.bs * 0.10
        else:
            self.hra = self.bs * 0.18
            self.da = self.bs * 0.07
            self.pf = self.bs * 0.09
            
        self.e_bs = self.bs + self.hra + self.da
        self.total_bs = self.e_bs - self.pf

    def putData(self):
        super().putData()
        print("Salary: ", self.bs)
        print("HRA: ", self.hra)
        print("DA: ", self.da)
        print("PF: ", self.pf)
        print("Gross Salary: ", self.e_bs)
        print("Net Salary: ", self.total_bs)

s1 = Salary()
s1.getData()
s1.calculateSal()
s1.putData()