class ABC:
    def getdata(self):
        self.__x=10
        self._y=20
        self.z=30
    def pub(self):
        print("Hello")
    def __pri(self):
        print("Hello")
    def _pro(self):
        print("Hello")    
        
class XYZ(ABC):
        def getdata(self):
            super().getdata() 
            self.z=50
            self._y=76
s1=XYZ()
s1.getdata()
print(s1._y)
print(s1.z)
print(s1.__x)
s1.__pri()
s1._pro()
s1.pub()
