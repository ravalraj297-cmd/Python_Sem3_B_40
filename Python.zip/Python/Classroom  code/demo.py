import employee1

employees = []

while True:
    print("\n=======employee menu========")
    print("1. Add Employee")
    print("2. Calculate Salary")
    print("3. Display All Employees")
    print("4. Search Employee by EID or Name")
    print("5. Delete Employee by EID or Name")
    print("6. Update Employee by EID or Name")
    print("7. Exit")

    # Error handling for invalid inputs (e.g., typing letters instead of numbers)
    try:
        ch = int(input("Enter your choice: "))
    except ValueError:
        print("Invalid input! Please enter a number.")
        continue

    if ch == 1:
        emp = employee1.emp()
        emp.getData()
        found = False
        for e in employees:
            if e.eid == emp.eid:
                found = True
                break
        
        if found:
            print("Employee ID already exists!")
        else:
            emp.calculatesal()
            employees.append(emp)
            print("Employee added successfully.")

    elif ch == 2:
        if len(employees) == 0:
            print("No employee data available.")
        else:
            for emp in employees:
                # Fixed method name inconsistency here
                emp.calculatesal() 
            print("Salary calculated successfully.")

    elif ch == 3:
        if len(employees) == 0:
            print("No employee data available.")
        else:
            for emp in employees:
                emp.putData()

    elif ch == 4:
        key = input("Enter employee EID or Name: ")
        found = False
        for emp in employees:
            if str(emp.eid) == key or emp.name.lower() == key.lower():
                emp.putData()
                found = True
        
        if not found:
            print("Employee not found.")

    elif ch == 5:
        if len(employees) == 0:
            print("No employee data available.")
        else:
            key = input("Enter employee EID or Name to delete: ")
            initial_count = len(employees)
            employees[:] = [emp for emp in employees if str(emp.eid) != key and emp.name.lower() != key.lower()]
            
            if len(employees) < initial_count:
                print("Employee deleted successfully.")
            else:
                print("Employee not found.")

    elif ch == 6:
        if len(employees) == 0:
            print("No employee data available.")
        else:
            key = input("Enter employee EID or Name to update: ")
            found = False
            for emp in employees:
                if str(emp.eid) == key or emp.name.lower() == key.lower():
                    print("Enter new details:")
                    emp.getData()
                    emp.calculatesal()
                    found = True
                    print("Employee updated successfully.")
                    break
            
            if not found:
                print("Employee not found.")

    elif ch == 7:
        print("Exiting program. Goodbye!")
        break

    else:
        print("Invalid choice! Please enter a number between 1 and 7.")