# def hello():
#     print("hello World")
# hello()
# def addition(a,b):
#         c=a+b
#         return c
# x=int(input("Enter value 1 "))
# y=int(input("Enter value 2 "))
# z=addition(x,y)
# print("ans is ",z)
# #############################################
# def caluclation(a,b):
#     return a+b,a-b,a*b
# x=int(input("Enter value 1 "))
# y=int(input("Enter value 1 "))
# z=caluclation(x,y)
# print("ans is ",z)
# p,q,r=caluclation(x,y)
# print(p,q,r)
############################################
def student(rno,name,age):
    print("roll no =",rno)
    print("Name no =",name)
    print("Age no =",age)
student(40,"Raj",19)
student(35,"Vatsal",19)
student(5,"Yash",19)