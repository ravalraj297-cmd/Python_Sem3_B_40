"""Program 1.4: Celsius to Fahrenheit and Kelvin.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""

celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = celsius * 9 / 5 + 32
kelvin = celsius + 273.15
print("Fahrenheit:", round(fahrenheit, 2), "F")
print("Kelvin:", round(kelvin, 2), "K")
