"""Program 1.18: Fibonacci series with while loop.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""
terms = int(input("How many terms? "))
a, b, count = 0, 1, 0
while count < terms:
    print(a, end=" ")
    a, b = b, a + b
    count += 1
print()
