"""Program 1.6: salary calculator.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""

basic = float(input("Enter basic salary: "))
hra = basic * 0.20
da = basic * 0.10
pf = basic * 0.12
gross = basic + hra + da
print("Gross salary:", round(gross, 2))
print("Net salary:", round(gross - pf, 2))
