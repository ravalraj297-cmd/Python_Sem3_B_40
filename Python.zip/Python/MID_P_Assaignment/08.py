"""Program 1.8: kilometre converter.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""

kilometres = float(input("Enter distance in kilometres: "))
print("Metres:", round(kilometres * 1000, 2))
print("Centimetres:", round(kilometres * 100000, 2))
print("Miles:", round(kilometres * 0.621371, 2))
print("Feet:", round(kilometres * 3280.84, 2))
