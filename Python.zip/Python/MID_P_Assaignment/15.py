"""Program 1.15: multiplication table.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""

number = int(input("Enter a number: "))
for value in range(1, 11):
    print(number, "x", value, "=", number * value)
