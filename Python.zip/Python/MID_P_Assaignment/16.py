"""Program 1.16: factorial using a for loop.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""
number = int(input("Enter a non-negative integer: "))
if number < 0:
    print("Factorial is not defined for negative numbers.")
else:
    fact = 1
    for value in range(2, number + 1):
        fact *= value
    print(number, "! =", fact)
