"""Program 1.23: sums of natural numbers, squares and cubes.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""
number = int(input("Enter N: "))
natural = squares = cubes = 0
for value in range(1, number + 1):
    natural += value
    squares += value ** 2
    cubes += value ** 3
print("Natural number sum:", natural)
print("Square sum:", squares)
print("Cube sum:", cubes)
