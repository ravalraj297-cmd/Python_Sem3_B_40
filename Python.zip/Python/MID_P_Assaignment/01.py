"""Program 1.1: print basic student details.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""

name = "Your Full Name"
roll_no = "Your Roll Number"
programme = "M.Sc. IT"
semester = "Semester 1"

print(name)
print(roll_no)
print(programme)
print(semester)
