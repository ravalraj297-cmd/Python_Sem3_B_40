"""Program 1.2: formatted introduction.

Coursework: Python Practical Assignment
Student: Raj Raval | Roll No: 40 | Div: B | Enrollment: 25004500210106
"""

name = input("Enter your name: ")
age = input("Enter your age: ")
city = input("Enter your favourite city: ")
print("Hello! My name is " + name + ". I am " + age + " years old and I love " + city + ".")
