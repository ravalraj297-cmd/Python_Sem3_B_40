product = {
    101: {
        "pname": "Laptop",
        "price": 50000,
        "quantity": 10,
        "salesman": "John Doe"
    },

    102: {
        "pname": "Smartphone",
        "price": 20000,
        "quantity": 20,
        "salesman": "Jane Smith"
    },

    103: {
        "pname": "Tablet",
        "price": 15000,
        "quantity": 15,
        "salesman": "Mike Johnson"
    }
}


# 1. ADD RECORD
def add_record():
    pid = int(input("Enter Product ID: "))

    pname = input("Enter Product Name: ")
    price = float(input("Enter Product Price: "))
    quantity = int(input("Enter Product Quantity: "))
    salesman = input("Enter Salesman Name: ")

    product[pid] = {
        "pname": pname,
        "price": price,
        "quantity": quantity,
        "salesman": salesman
    }

    print("Record added successfully!")


# 2. UPDATE RECORD
def update_record():
    pid = int(input("Enter Product ID to update: "))

    if pid in product:

        product[pid]["pname"] = input("Enter new Product Name: ")

        product[pid]["price"] = float(
            input("Enter new Product Price: ")
        )

        product[pid]["quantity"] = int(
            input("Enter new Product Quantity: ")
        )

        product[pid]["salesman"] = input(
            "Enter new Salesman Name: "
        )

        print("Record updated successfully!")

    else:
        print("Record not found!")


# 3. DELETE RECORD
def delete_record():
    pid = int(input("Enter Product ID to delete: "))

    if pid in product:
        del product[pid]
        print("Record deleted successfully!")

    else:
        print("Record not found!")


# 4. SEARCH RECORD
def search_record():
    pid = int(input("Enter Product ID to search: "))

    if pid in product:

        print("Product ID:", pid)
        print("Product Name:", product[pid]["pname"])
        print("Price:", product[pid]["price"])
        print("Quantity:", product[pid]["quantity"])
        print("Salesman:", product[pid]["salesman"])

    else:
        print("Record not found!")


# 5. DISPLAY RECORD
def display_record():

    for pid, details in product.items():

        print("\nProduct ID:", pid)
        print("Product Name:", details["pname"])
        print("Price:", details["price"])
        print("Quantity:", details["quantity"])
        print("Salesman:", details["salesman"])


# 6. SORT RECORDS BY PRICE
def sort_records():

    sorted_product = sorted(
        product.items(),
        key=lambda x: x[1]["price"]
    )

    for pid, details in sorted_product:
        print(pid, details)


# 7. MINIMUM PRICE
def minimum_sales():

    minimum = min(
        product.items(),
        key=lambda x: x[1]["price"]
    )

    print("Minimum Price Record:")
    print(minimum)


# 8. MAXIMUM PRICE
def maximum_sales():

    maximum = max(
        product.items(),
        key=lambda x: x[1]["price"]
    )

    print("Maximum Price Record:")
    print(maximum)


# 9. TOP THREE RECORDS
def top_three():

    top = sorted(
        product.items(),
        key=lambda x: x[1]["price"],
        reverse=True
    )[:3]

    print("\nTop Three Records:")

    for pid, details in top:
        print(pid, details)


# 10. LAST THREE RECORDS
def last_three():

    last = sorted(
        product.items(),
        key=lambda x: x[1]["price"]
    )[:3]

    print("\nLast Three Records:")

    for pid, details in last:
        print(pid, details)


# MENU DRIVEN PROGRAM
while True:

    print("\n1. Add Record")
    print("2. Update Record")
    print("3. Delete Record")
    print("4. Search Record")
    print("5. Display Record")
    print("6. Sort Records")
    print("7. Minimum Sales")
    print("8. Maximum Sales")
    print("9. Top Three Records")
    print("10. Last Three Records")
    print("0. Exit")

    choice = int(input("\nEnter your choice: "))


    match choice:

        case 1:
            add_record()

        case 2:
            update_record()

        case 3:
            delete_record()

        case 4:
            search_record()

        case 5:
            display_record()

        case 6:
            sort_records()

        case 7:
            minimum_sales()

        case 8:
            maximum_sales()

        case 9:
            top_three()

        case 10:
            last_three()

        case 0:
            print("Program Closed!")
            break

        case _:
            print("Invalid Choice!")
        