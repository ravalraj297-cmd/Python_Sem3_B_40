"""Filter student names having character length strictly less than 5."""

students = ['Amit', 'Bhavna', 'Dax', 'Kiran', 'Rohit']
result = list(filter(lambda name: len(name) < 6, students))
print(result)
