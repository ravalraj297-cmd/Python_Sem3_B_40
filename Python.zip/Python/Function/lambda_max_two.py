"""Find the maximum of two numbers using a ternary lambda function."""

maximum = lambda first, second: first if first > second else second
print(maximum(25, 18))
