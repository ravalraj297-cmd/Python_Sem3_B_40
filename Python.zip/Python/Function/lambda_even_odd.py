"""Transform a number using lambda: multiply by 5 if even, or add 5 if odd."""

change_number = lambda number: number * 5 if number % 2 == 0 else number * 10
number = int(input('Enter number: '))
print(change_number(number))
