"""Remove empty/whitespace-only strings from a list using filter()."""

words = ['Python', '', 'List', '', 'Function']
result = list(filter(lambda word: word != '', words))
print(result)
