"""Calculate and print the total number of elements in a list using len()."""

numbers = [10, 20, 30, 40, 50]
print('Length:', len(numbers))
