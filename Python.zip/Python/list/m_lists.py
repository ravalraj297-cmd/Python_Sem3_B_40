"""Merge two lists into one using the concatenation operator (+)."""

first = [1, 2, 3]
second = [4, 5, 6]
merged = first + second
print(merged)
