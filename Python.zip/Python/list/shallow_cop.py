"""Demonstrate shallow copying of a list using the copy() method."""

original = [10, 20, 30]
copied = original.copy()
copied.append(40)
print('Original:', original)
print('Copy:', copied)
