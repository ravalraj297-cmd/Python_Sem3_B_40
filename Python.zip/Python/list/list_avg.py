"""Calculate the arithmetic average of numbers stored in a list."""

numbers = [65, 72, 80, 91, 77]
total = 0
for number in numbers:
    total += number
print('Average:', total / len(numbers))
