"""Check if a specific search item exists in a list using the "in" operator."""

items = ['pen', 'book', 'bag', 'scale']
item = input('Enter item to search: ')
if item in items:
    print('Element exists.')
else:
    print('Element does not exist.')
