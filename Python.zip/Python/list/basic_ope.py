"""Demonstrate append, insert, and remove operations on a list."""

items = ['pen', 'pencil', 'eraser']
items.append('book')
items.insert(1, 'marker')
items.remove('pencil')
print(items)
