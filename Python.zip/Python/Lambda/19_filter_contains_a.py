"""Filter words that contain the vowel "a" (case-insensitive)."""

words = ['python', 'apple', 'banana', 'list', 'java']
result = list(filter(lambda word: 'a' in word.lower(), words))
print(result)
