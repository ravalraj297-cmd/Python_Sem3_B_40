"""Calculate cube of a number using a lambda function with exponentiation operator (**)."""

cube = lambda number: number ** 3
print(cube(4))
