"""Check if a number is Even or Odd using a conditional lambda expression."""

check_even = lambda number: 'Even' if number % 2 == 0 else 'Odd'
print(check_even(17))
