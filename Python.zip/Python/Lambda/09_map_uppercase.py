"""Convert all strings in a list to uppercase using map() and lambda."""

words = ['python', 'lambda', 'function']
result = list(map(lambda word: word.upper(), words))
print(result)
