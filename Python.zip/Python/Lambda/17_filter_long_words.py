"""Filter words having length strictly greater than 5 characters."""

words = ['cat', 'python', 'apple', 'programming', 'book']
result = list(filter(lambda word: len(word) > 5, words))
print(result)
