"""Filter out blank / empty strings from a list of words."""

words = ['Python', '', 'Lambda', '', 'Program']
result = list(filter(lambda word: word != '', words))
print(result)
