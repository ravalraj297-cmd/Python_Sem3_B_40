"""Extract numbers strictly less than 25 using filter() and lambda."""

numbers = [12, 55, 24, 72, 9, 45]
result = list(filter(lambda number: number < 25, numbers))
print(result)
