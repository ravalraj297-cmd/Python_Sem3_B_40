"""Sort numbers in descending order using sorted() with reverse=True."""

numbers = [12, 45, 7, 31, 20]
result = sorted(numbers, key=lambda number: number, reverse=True)
print(result)
