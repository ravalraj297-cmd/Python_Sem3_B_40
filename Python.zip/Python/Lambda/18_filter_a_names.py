"""Filter names starting with capital letter A using startswith()."""

names = ['Amit', 'Bina', 'Aarav', 'Diya', 'Anu']
result = list(filter(lambda name: name.startswith('A'), names))
print(result)
