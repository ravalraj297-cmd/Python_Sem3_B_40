"""Double each element in a list using map() with a lambda function."""

numbers = [1, 2, 3, 4, 5]
result = list(map(lambda number: number * 2, numbers))
print(result)
