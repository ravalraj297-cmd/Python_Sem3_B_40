"""Extract positive numbers strictly greater than zero using filter() and lambda."""

numbers = [-10, 5, 0, -3, 12, 8]
result = list(filter(lambda number: number > 0, numbers))
print(result)
