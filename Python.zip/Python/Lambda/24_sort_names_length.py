"""Sort names according to their length using sorted() with key=len."""

names = ['Amit', 'Bina', 'Christopher', 'Diya', 'Kabir']
result = sorted(names, key=lambda name: len(name))
print(result)
