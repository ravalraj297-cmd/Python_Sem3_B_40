"""Calculate square of a number using a single-argument lambda function."""

square = lambda number: number * number
print(square(6))
