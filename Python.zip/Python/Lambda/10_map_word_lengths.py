"""Compute the length of each word in a string list using map() and len()."""

words = ['python', 'list', 'lambda', 'program']
result = list(map(lambda word: len(word), words))
print(result)
