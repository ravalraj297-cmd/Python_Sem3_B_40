"""Find the maximum of two numbers using a ternary conditional lambda function."""

maximum = lambda first, second: first if first > second else second
print(maximum(12, 25))
