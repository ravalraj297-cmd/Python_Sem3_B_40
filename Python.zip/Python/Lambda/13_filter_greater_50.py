"""Extract numbers strictly greater than 50 using filter() and lambda."""

numbers = [12, 55, 34, 72, 90, 45]
result = list(filter(lambda number: number > 50, numbers))
print(result)
