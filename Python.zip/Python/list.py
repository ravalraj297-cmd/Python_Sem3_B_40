number = [10,8,24,56,34,67,45,75,36,85]
# div3 = [n for n in number if n % 3 == 0]
# div9 = [n for n in number if n % 9 == 0]


# gra10 = [n for n in number if n > 10]
# gra20 = [n for n in number if n > 20]
# gra30= [n for n in number if n > 30]


# even = [n for n in number if n % 2 == 0]
# odd = [n for n in number if n % 2 != 0]


# print("Divisible by 3:",div3)
# print("Divisible by 9:",div9)
# print("Grater 10:",gra10)
# print("Grater 10:",gra20)
# print("Grater 10:",gra30)
# print("Even no:",even)
# print("Odd no:",odd)
# >10
# >20
# >30
# even/odd

# print(max(number))
# print(min(number))
# print(sum(number))
# Avg=sum(number)/len(number)
# print(Avg)

def operation(a,b):
    c=a+b
    d=a-b
    e=a*b
    f=a/b
    return c,d,e,f

p,q,r,s=operation(2473,3)

print(p,q,r,s)