#input data in matrix using user input
rows = int(input("Enter number of rows: "))
cols = int(input("Enter number of coloums: "))

#input First Matrix
print("Enter elements of matrix A: ")
A =[]
for i in range(rows):
    row = []
    for j in range(cols):
        row.append(int(input("Enter Value: ")))
    A.append(row)
for i in A:
    for j in i:
        print(j,end=" ")
    print(" ")